const DEFAULTS = { targetSite: "https://example.com", apiPatterns: ["/api/"], includeHeaders: true, includeRequestBody: true };
const sessions = new Map();
const pending = new Map();

async function settings() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
}
function normalizeOrigin(value) {
  try { return new URL(value).origin; } catch { return null; }
}
async function isTrackedTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const cfg = await settings();
    return normalizeOrigin(tab.url) === normalizeOrigin(cfg.targetSite);
  } catch { return false; }
}
async function isApi(url) {
  const cfg = await settings();
  if (!cfg.apiPatterns?.length) return true;
  return cfg.apiPatterns.some(p => url.toLowerCase().includes(String(p).toLowerCase()));
}
function bodyToJson(requestBody) {
  if (!requestBody) return undefined;
  if (requestBody.formData) return { formData: requestBody.formData };
  if (requestBody.raw) {
    return { raw: requestBody.raw.map(x => ({ bytesLength: x.bytes ? x.bytes.byteLength : 0, file: x.file })) };
  }
}
function secureHeaders(headers) {
  return (headers || []).map(h => {
    const sensitive = /^(authorization|proxy-authorization|cookie|set-cookie)$/i.test(h.name);
    return { name: h.name, value: sensitive ? "[REDACTED]" : (h.value ?? "") };
  });
}
function ensureSession(tabId, pageUrl) {
  if (!sessions.has(tabId)) sessions.set(tabId, { tabId, pageUrl, startedAt: new Date().toISOString(), requests: [] });
  return sessions.get(tabId);
}
async function eligible(d) { return d.tabId >= 0 && await isTrackedTab(d.tabId) && await isApi(d.url); }

chrome.webRequest.onBeforeRequest.addListener(async d => {
  if (!(await eligible(d))) return;
  const cfg = await settings();
  const tab = await chrome.tabs.get(d.tabId).catch(() => null);
  const item = {
    requestId: d.requestId, method: d.method, url: d.url, type: d.type,
    initiator: d.initiator || null, startedAt: new Date(d.timeStamp).toISOString(),
    startTimestampMs: d.timeStamp
  };
  if (cfg.includeRequestBody) item.requestBody = bodyToJson(d.requestBody);
  pending.set(`${d.tabId}:${d.requestId}`, item);
  ensureSession(d.tabId, tab?.url || "");
}, { urls: ["<all_urls>"] }, ["requestBody"]);

chrome.webRequest.onBeforeSendHeaders.addListener(async d => {
  const item = pending.get(`${d.tabId}:${d.requestId}`); if (!item) return;
  if ((await settings()).includeHeaders) item.requestHeaders = secureHeaders(d.requestHeaders);
}, { urls: ["<all_urls>"] }, ["requestHeaders", "extraHeaders"]);

chrome.webRequest.onHeadersReceived.addListener(async d => {
  const item = pending.get(`${d.tabId}:${d.requestId}`); if (!item) return;
  item.responseHeadersReceivedAt = new Date(d.timeStamp).toISOString();
  item.timeToFirstResponseHeadersMs = Math.max(0, d.timeStamp - item.startTimestampMs);
  if ((await settings()).includeHeaders) item.responseHeaders = secureHeaders(d.responseHeaders);
  item.statusCode = d.statusCode;
  item.statusLine = d.statusLine;
}, { urls: ["<all_urls>"] }, ["responseHeaders", "extraHeaders"]);

async function finish(d, error) {
  const key = `${d.tabId}:${d.requestId}`; const item = pending.get(key); if (!item) return;
  item.completedAt = new Date(d.timeStamp).toISOString();
  item.endTimestampMs = d.timeStamp;
  item.totalDurationMs = Math.max(0, d.timeStamp - item.startTimestampMs);
  item.fromCache = d.fromCache || false;
  item.ip = d.ip || null;
  if (error) item.error = d.error;
  ensureSession(d.tabId, "").requests.push(item);
  pending.delete(key);
}
chrome.webRequest.onCompleted.addListener(d => finish(d, false), { urls: ["<all_urls>"] });
chrome.webRequest.onErrorOccurred.addListener(d => finish(d, true), { urls: ["<all_urls>"] });

function fileStamp() { return new Date().toISOString().replace(/[:.]/g, "-"); }
async function exportTab(tabId, reason="manual") {
  for (const [k, item] of pending) {
    if (k.startsWith(`${tabId}:`)) {
      item.incomplete = true; item.completedAt = new Date().toISOString();
      ensureSession(tabId, "").requests.push(item); pending.delete(k);
    }
  }
  const session = sessions.get(tabId);
  if (!session || !session.requests.length) return { ok:false, message:"No captured API requests." };
  const payload = { extension:"Arminder API Tracker", exportedAt:new Date().toISOString(), reason, ...session };
  const url = "data:application/json;charset=utf-8," + encodeURIComponent(JSON.stringify(payload, null, 2));
  await chrome.downloads.download({ url, filename:`arminder+${fileStamp()}.json`, saveAs:false, conflictAction:"uniquify" });
  sessions.delete(tabId);
  return { ok:true, count:payload.requests.length };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === "STATUS") {
      const active = await isTrackedTab(msg.tabId);
      const count = (sessions.get(msg.tabId)?.requests.length || 0) + [...pending.keys()].filter(k=>k.startsWith(`${msg.tabId}:`)).length;
      reply({ active, count, config: await settings() });
    } else if (msg.type === "EXPORT") reply(await exportTab(msg.tabId));
    else if (msg.type === "CLEAR") { sessions.delete(msg.tabId); for (const k of [...pending.keys()]) if(k.startsWith(`${msg.tabId}:`)) pending.delete(k); reply({ok:true}); }
  })(); return true;
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.url && sessions.has(tabId) && !(await isTrackedTab(tabId))) await exportTab(tabId, "left-target-site");
});
chrome.tabs.onRemoved.addListener(tabId => { if (sessions.has(tabId)) exportTab(tabId, "tab-closed"); });
