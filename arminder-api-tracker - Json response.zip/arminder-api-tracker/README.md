# Arminder API Tracker

A Chrome Manifest V3 extension that activates only when the active tab matches the configured website origin. It captures API request timing and downloads JSON files named `arminder+<datetime>.json`.

## Install
1. Unzip the package.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose this folder.
5. Open the extension **Settings**, enter the website URL and API URL patterns.
6. Browse the configured website. Use the toolbar popup to monitor or export.

The extension also exports automatically when you navigate away from the configured site or close its tab.

## Captured fields
URL, method, resource type, start/end time, total duration, time to first response headers, status, cache flag, IP when available, request/response headers, request body metadata/form data, and network errors.

## Important limitations
- Chrome `webRequest` does not expose response bodies.
- Raw request bodies are recorded only as byte lengths, avoiding unsafe binary serialization.
- Authorization and cookie headers are redacted.
- `host_permissions` is broad because API hosts can differ from the page host. For stricter deployment, replace `<all_urls>` in `manifest.json` with the exact site and API origins.
- The duration is browser-observed end-to-end network time, not server-only execution time.
