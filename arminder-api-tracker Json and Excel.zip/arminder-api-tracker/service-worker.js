const DEFAULTS = { targetSite: "https://example.com", apiPatterns: ["/api/"], includeHeaders: true, includeRequestBody: true, exportFormat: "json" };
const sessions = new Map();
const pending = new Map();

async function settings() {
  return { ...DEFAULTS, ...(await chrome.storage.local.get(DEFAULTS)) };
}
function normalizeOrigin(value) {
  try { return new URL(value).origin; } catch { return null; }
}
async function isTrackedTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const cfg = await settings();
    return normalizeOrigin(tab.url) === normalizeOrigin(cfg.targetSite);
  } catch { return false; }
}
async function isApi(url) {
  const cfg = await settings();
  if (!cfg.apiPatterns?.length) return true;
  return cfg.apiPatterns.some(p => url.toLowerCase().includes(String(p).toLowerCase()));
}
function bodyToJson(requestBody) {
  if (!requestBody) return undefined;
  if (requestBody.formData) return { formData: requestBody.formData };
  if (requestBody.raw) {
    return { raw: requestBody.raw.map(x => ({ bytesLength: x.bytes ? x.bytes.byteLength : 0, file: x.file })) };
  }
}
function secureHeaders(headers) {
  return (headers || []).map(h => {
    const sensitive = /^(authorization|proxy-authorization|cookie|set-cookie)$/i.test(h.name);
    return { name: h.name, value: sensitive ? "[REDACTED]" : (h.value ?? "") };
  });
}
function ensureSession(tabId, pageUrl) {
  if (!sessions.has(tabId)) sessions.set(tabId, { tabId, pageUrl, startedAt: new Date().toISOString(), requests: [] });
  return sessions.get(tabId);
}
async function eligible(d) { return d.tabId >= 0 && await isTrackedTab(d.tabId) && await isApi(d.url); }

chrome.webRequest.onBeforeRequest.addListener(async d => {
  if (!(await eligible(d))) return;
  const cfg = await settings();
  const tab = await chrome.tabs.get(d.tabId).catch(() => null);
  const item = {
    requestId: d.requestId, method: d.method, url: d.url, type: d.type,
    initiator: d.initiator || null, startedAt: new Date(d.timeStamp).toISOString(),
    startTimestampMs: d.timeStamp
  };
  if (cfg.includeRequestBody) item.requestBody = bodyToJson(d.requestBody);
  pending.set(`${d.tabId}:${d.requestId}`, item);
  ensureSession(d.tabId, tab?.url || "");
}, { urls: ["<all_urls>"] }, ["requestBody"]);

chrome.webRequest.onBeforeSendHeaders.addListener(async d => {
  const item = pending.get(`${d.tabId}:${d.requestId}`); if (!item) return;
  if ((await settings()).includeHeaders) item.requestHeaders = secureHeaders(d.requestHeaders);
}, { urls: ["<all_urls>"] }, ["requestHeaders", "extraHeaders"]);

chrome.webRequest.onHeadersReceived.addListener(async d => {
  const item = pending.get(`${d.tabId}:${d.requestId}`); if (!item) return;
  item.responseHeadersReceivedAt = new Date(d.timeStamp).toISOString();
  item.timeToFirstResponseHeadersMs = Math.max(0, d.timeStamp - item.startTimestampMs);
  if ((await settings()).includeHeaders) item.responseHeaders = secureHeaders(d.responseHeaders);
  item.statusCode = d.statusCode;
  item.statusLine = d.statusLine;
}, { urls: ["<all_urls>"] }, ["responseHeaders", "extraHeaders"]);

async function finish(d, error) {
  const key = `${d.tabId}:${d.requestId}`; const item = pending.get(key); if (!item) return;
  item.completedAt = new Date(d.timeStamp).toISOString();
  item.endTimestampMs = d.timeStamp;
  item.totalDurationMs = Math.max(0, d.timeStamp - item.startTimestampMs);
  item.fromCache = d.fromCache || false;
  item.ip = d.ip || null;
  if (error) item.error = d.error;
  ensureSession(d.tabId, "").requests.push(item);
  pending.delete(key);
}
chrome.webRequest.onCompleted.addListener(d => finish(d, false), { urls: ["<all_urls>"] });
chrome.webRequest.onErrorOccurred.addListener(d => finish(d, true), { urls: ["<all_urls>"] });

function fileStamp() { return new Date().toISOString().replace(/[:.]/g, "-"); }
function xmlEscape(v) {
  return String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
}
function colName(n) { let s=""; while(n){ n--; s=String.fromCharCode(65+n%26)+s; n=Math.floor(n/26); } return s; }
function crc32(bytes) {
  let c=0xffffffff;
  for (const b of bytes) { c^=b; for(let k=0;k<8;k++) c=(c>>>1)^((c&1)?0xedb88320:0); }
  return (c^0xffffffff)>>>0;
}
function u16(n){ return [n&255,(n>>>8)&255]; }
function u32(n){ return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]; }
function zipStore(files) {
  const enc=new TextEncoder(), chunks=[], central=[]; let offset=0;
  const add=a=>{chunks.push(new Uint8Array(a)); offset+=a.length;};
  for (const f of files) {
    const name=enc.encode(f.name), data=typeof f.data==="string"?enc.encode(f.data):f.data, crc=crc32(data), localOffset=offset;
    add([...u32(0x04034b50),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),...u16(0),...name]); add(data);
    central.push([...u32(0x02014b50),...u16(20),...u16(20),...u16(0),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(localOffset),...name]);
  }
  const centralOffset=offset; for(const c of central) add(c); const centralSize=offset-centralOffset;
  add([...u32(0x06054b50),...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(centralSize),...u32(centralOffset),...u16(0)]);
  const total=chunks.reduce((n,c)=>n+c.length,0), out=new Uint8Array(total); let pos=0; for(const c of chunks){out.set(c,pos);pos+=c.length;} return out;
}
function sheetXml(rows) {
  const body=rows.map((row,ri)=>`<row r="${ri+1}">${row.map((v,ci)=>{
    const ref=colName(ci+1)+(ri+1); if(typeof v==="number" && Number.isFinite(v)) return `<c r="${ref}"><v>${v}</v></c>`;
    return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(v)}</t></is></c>`;
  }).join("")}</row>`).join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
}
function makeExcel(payload) {
  const headers=["Request ID","Method","URL","Type","Started At","Response Headers At","Completed At","Time to First Response Headers (ms)","Total Duration (ms)","Status Code","Status Line","From Cache","IP","Initiator","Error","Request Headers","Response Headers","Request Body"];
  const rows=[headers,...payload.requests.map(r=>[r.requestId,r.method,r.url,r.type,r.startedAt,r.responseHeadersReceivedAt||"",r.completedAt||"",r.timeToFirstResponseHeadersMs??"",r.totalDurationMs??"",r.statusCode??"",r.statusLine||"",String(r.fromCache??false),r.ip||"",r.initiator||"",r.error||"",JSON.stringify(r.requestHeaders||[]),JSON.stringify(r.responseHeaders||[]),JSON.stringify(r.requestBody||{})])];
  const durations=payload.requests.map(r=>r.totalDurationMs).filter(Number.isFinite);
  const ok=payload.requests.filter(r=>r.statusCode>=200&&r.statusCode<400).length;
  const summary=[["Field","Value"],["Website",payload.pageUrl],["Tracking started",payload.startedAt],["Exported at",payload.exportedAt],["Export reason",payload.reason],["Total requests",payload.requests.length],["Successful requests",ok],["Failed/error requests",payload.requests.length-ok],["Average duration (ms)",durations.length?Math.round(durations.reduce((a,b)=>a+b,0)/durations.length*100)/100:""]];
  return zipStore([
    {name:"[Content_Types].xml",data:`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`},
    {name:"_rels/.rels",data:`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`},
    {name:"xl/workbook.xml",data:`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="API Requests" sheetId="1" r:id="rId1"/><sheet name="Session Summary" sheetId="2" r:id="rId2"/></sheets></workbook>`},
    {name:"xl/_rels/workbook.xml.rels",data:`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>`},
    {name:"xl/worksheets/sheet1.xml",data:sheetXml(rows)}, {name:"xl/worksheets/sheet2.xml",data:sheetXml(summary)}
  ]);
}
async function exportTab(tabId, reason="manual") {
  for (const [k, item] of pending) {
    if (k.startsWith(`${tabId}:`)) { item.incomplete=true; item.completedAt=new Date().toISOString(); ensureSession(tabId,"").requests.push(item); pending.delete(k); }
  }
  const session=sessions.get(tabId);
  if (!session || !session.requests.length) return {ok:false,message:"No captured API requests."};
  const cfg=await settings();
  const payload={extension:"Arminder API Tracker",exportedAt:new Date().toISOString(),reason,...session};
  const format=cfg.exportFormat==="excel"?"excel":"json";
  let url, extension;
  if(format==="excel"){ const bytes=makeExcel(payload); let binary=""; for(let i=0;i<bytes.length;i+=0x8000) binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000)); url="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,"+btoa(binary); extension="xlsx"; }
  else { url="data:application/json;charset=utf-8,"+encodeURIComponent(JSON.stringify(payload,null,2)); extension="json"; }
  await chrome.downloads.download({url,filename:`arminder+${fileStamp()}.${extension}`,saveAs:false,conflictAction:"uniquify"});
  sessions.delete(tabId);
  return {ok:true,count:payload.requests.length,format};
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === "STATUS") {
      const active = await isTrackedTab(msg.tabId);
      const count = (sessions.get(msg.tabId)?.requests.length || 0) + [...pending.keys()].filter(k=>k.startsWith(`${msg.tabId}:`)).length;
      reply({ active, count, config: await settings() });
    } else if (msg.type === "EXPORT") reply(await exportTab(msg.tabId));
    else if (msg.type === "CLEAR") { sessions.delete(msg.tabId); for (const k of [...pending.keys()]) if(k.startsWith(`${msg.tabId}:`)) pending.delete(k); reply({ok:true}); }
  })(); return true;
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.url && sessions.has(tabId) && !(await isTrackedTab(tabId))) await exportTab(tabId, "left-target-site");
});
chrome.tabs.onRemoved.addListener(tabId => { if (sessions.has(tabId)) exportTab(tabId, "tab-closed"); });
